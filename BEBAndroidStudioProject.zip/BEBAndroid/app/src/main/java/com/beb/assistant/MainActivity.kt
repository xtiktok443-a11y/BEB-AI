package com.beb.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var answer: TextView
    private lateinit var listenButton: Button
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private var onlineMode = false
    private lateinit var apiUrl: EditText
    private lateinit var apiKey: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Speech recognition is unavailable on this device."
            listenButton.isEnabled = false
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 30, 24, 24)
            setBackgroundColor(0xFF08111F.toInt())
        }
        val title = TextView(this).apply {
            text = "BEB AI"
            textSize = 34f
            setTextColor(0xFF58D6FF.toInt())
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Your bilingual voice assistant"
            textSize = 15f
            setTextColor(0xFFB8D8E8.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 24)
        }
        listenButton = Button(this).apply {
            text = "🎙  কথা বলুন / Speak"
            textSize = 18f
            setOnClickListener { startListening() }
        }
        answer = TextView(this).apply {
            text = "Hello! আমি BEB. কীভাবে সাহায্য করতে পারি?"
            textSize = 18f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 28, 0, 24)
            gravity = Gravity.CENTER
        }
        val modeLabel = TextView(this).apply {
            text = "Mode: Hybrid (offline commands + online AI-ready settings)"
            setTextColor(0xFF8FB4C8.toInt())
            textSize = 12f
            gravity = Gravity.CENTER
        }
        val settings = TextView(this).apply {
            text = "Online AI connection (optional)"
            textSize = 16f
            setTextColor(0xFF58D6FF.toInt())
            setPadding(0, 22, 0, 6)
        }
        apiUrl = EditText(this).apply {
            hint = "HTTPS API endpoint (optional)"
            setSingleLine(true)
            textSize = 14f
        }
        apiKey = EditText(this).apply {
            hint = "API key (do not share this phone)"
            setSingleLine(true)
            textSize = 14f
        }
        val note = TextView(this).apply {
            text = "এই starter version-এ offline time/date/greeting commands কাজ করে। Online AI চালাতে একটি নিরাপদ backend endpoint যুক্ত করতে হবে; API key সরাসরি APK-তে রাখা নিরাপদ নয়।"
            setTextColor(0xFF9BB0C0.toInt())
            textSize = 12f
            setPadding(0, 10, 0, 0)
        }
        root.addView(title, match())
        root.addView(status, match())
        root.addView(listenButton, match())
        root.addView(answer, match())
        root.addView(modeLabel, match())
        root.addView(settings, match())
        root.addView(apiUrl, match())
        root.addView(apiKey, match())
        root.addView(note, match())
        setContentView(root)
    }

    private fun match() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("Speech recognition is not available.")
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = "Listening… / শুনছি…" }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "Processing… / বুঝছি…" }
            override fun onError(error: Int) {
                status.text = "আবার চেষ্টা করুন / Please try again."
                listenButton.isEnabled = true
            }
            override fun onResults(results: Bundle?) {
                listenButton.isEnabled = true
                val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                answer.text = "You: $spoken"
                handleCommand(spoken)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak in Bangla or English")
        }
        listenButton.isEnabled = false
        recognizer?.startListening(intent)
    }

    private fun handleCommand(raw: String) {
        val q = raw.lowercase(Locale.ROOT)
        val response = when {
            q.contains("time") || q.contains("সময়") || q.contains("কটা") ->
                "এখন সময় ${SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())}"
            q.contains("date") || q.contains("তারিখ") || q.contains("আজ") ->
                "আজ ${SimpleDateFormat("EEEE, dd MMMM yyyy", Locale("bn", "BD")).format(Date())}"
            q.contains("hello") || q.contains("hi") || q.contains("হ্যালো") || q.contains("হাই") ->
                "Hello! আমি BEB. তোমাকে কীভাবে সাহায্য করতে পারি?"
            q.contains("your name") || q.contains("তোমার নাম") ->
                "আমার নাম BEB, তোমার personal AI assistant."
            q.contains("thank") || q.contains("ধন্যবাদ") ->
                "স্বাগতম! / You're welcome!"
            else -> "আমি এখনো এই কমান্ডটি অফলাইনে বুঝতে পারছি না। Online AI যুক্ত করলে আরও প্রশ্নের উত্তর দিতে পারব।"
        }
        answer.text = response
        status.text = "Ready / প্রস্তুত"
        speak(response)
    }

    private fun speak(text: String) {
        if (!::tts.isInitialized) return
        val lang = if (text.any { it in '\u0980'..'\u09FF' }) Locale("bn", "BD") else Locale.US
        val result = tts.setLanguage(lang)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts.language = Locale.US
        }
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "beb_reply")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) tts.language = Locale.US
    }

    override fun onDestroy() {
        recognizer?.destroy()
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
