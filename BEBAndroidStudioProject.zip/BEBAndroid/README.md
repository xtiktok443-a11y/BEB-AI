# BEB AI — Android Studio starter project

BEB is a bilingual (Bangla + English) Android voice-assistant starter app.

## Included
- Android microphone permission and speech recognition
- Text-to-speech replies
- Offline starter commands: greeting, assistant name, date, and time
- Hybrid-ready project structure and optional endpoint/key fields in the UI

## Important limitations
This starter project does **not** yet call an online AI service. The endpoint/key fields are placeholders. For a real hybrid assistant, connect the app to your own HTTPS backend, and let the backend call an AI provider. Do not ship a private AI API key inside an APK: APKs can be reverse engineered.
Speech recognition and TTS language availability depend on the Android device's installed speech services and language packs. If Bangla speech recognition is unavailable, install/update Google's speech services and Bangla language support, or use a backend speech service.

## Build APK
1. Install Android Studio (latest stable) and Android SDK Platform 35.
2. Open this `BEBAndroid` folder in Android Studio.
3. Wait for Gradle sync. If prompted, install the Android Gradle Plugin/SDK components.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Find the debug APK at `app/build/outputs/apk/debug/app-debug.apk`.
6. On your Android phone, transfer the APK, allow installation from that source, and install.

## Build a release APK
Use **Build > Generate Signed Bundle / APK > APK**, create and safely store a signing key, then complete the wizard.

## Minimum requirements
- Android 6.0 (API 23) or newer
- Microphone permission
- Internet permission is included for a future backend connection
